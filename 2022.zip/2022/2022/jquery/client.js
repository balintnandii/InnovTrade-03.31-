$(function(){                              // Amint a DOM kész, lefut
    function show(data){                   // Megjelenítő függvény
      $('#output').empty();               // Kitörli a korábbi tartalmat
      $.each(data,function(i,item){       // Végigmegy az adatokon
        $('#output').append(              // HTML elemek hozzáadása
          `<div><h3>${item.name}</h3><p>${item.manufacturer} – ${item.price} USD</p></div>`
        );
      });
    }
  
    $('#all').click(()=>                   // Az "Összes" gombra kattintva
      $.get('/api/phones',show)             // GET kérés az összes telefonhoz
    );
  
    $('#id').click(()=>{                   // Az "ID" gombra kattintva
      let id=prompt('ID:');                // Bekéri az ID-t prompttal
      $.get(`/api/phones/${id}`,show)      // GET kérés a megadott ID-hez
        .fail(()=>alert('Nincs adat'));    // Ha 404, hibaüzenet
    });
  
    $('#manu').click(()=>{                 // A "Gyártó" gombra kattintva
      let m=prompt('Gyártó:');             // Bekéri a gyártó nevét
      $.get(`/api/phones/manufacturer/${m}`,show) // GET kérés gyártó szerint
        .fail(()=>alert('Nincs adat'));    // Hibakezelés
    });
  });