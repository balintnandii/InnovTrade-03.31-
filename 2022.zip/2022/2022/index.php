<?php
header('Content-Type: application/json');               // A válasz típusa JSON formátum  
$conn = new mysqli('localhost','root','','mydb');      // Kapcsolódás a MySQL adatbázishoz  
if($conn->connect_error){                              // Ellenőrzi, hogy sikerült-e a csatlakozás  
  http_response_code(500);                            // Ha nem, 500-as HTTP kódot ad vissza  
  echo json_encode(['error'=>'DB connection failed']); // Hibakód és üzenet JSON-ben  
  exit;                                               // Kilépés a szkriptből  
}
$action = $_GET['action'] ?? 'listAll';                 // Lekérdezés típusa, alapértelmezett: listAll  
$id = intval($_GET['id'] ?? 0);                        // ID lekérdezési paraméter, egész számmá konvertálva  
$man = $_GET['manufacturer'] ?? '';                    // Gyártó szerinti szűrés paramétere  
switch($action){                                       // Váltás a művelet típusától függően  
  case 'import':                                       // Telefon adatainak importálása TXT-ből  
    $f = __DIR__.'/telefon.txt';                      // A TXT fájl elérési útja  
    if(!file_exists($f)){                             // Ellenőrzi, hogy létezik-e a fájl  
      http_response_code(404);                        // Ha nem, 404-es választ küld  
      echo json_encode(['error'=>'File not found']); // Hibajelzés JSON-ben  
      exit;                                           // Kilépés a szkriptből  
    }
    $lines = file($f, FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES); // Soronként beolvassa a fájlt  
    $stmt = $conn->prepare("INSERT INTO phones(name,manufacturer,price) VALUES(?,?,?)"); // Előkészített SQL utasítás  
    $cnt = 0;                                         // Importált sorok számlálója  
    foreach($lines as $l){                            // Minden sor feldolgozása  
      list($n,$m,$p) = explode(';',$l);              // Sor feldarabolása a ";" mentén  
      $stmt->bind_param('ssd',$n,$m,$p);             // Paraméterek kötése: string,string,double  
      $stmt->execute();                              // SQL utasítás végrehajtása  
      $cnt++;                                        // Számláló növelése  
    }
    echo json_encode(['imported'=>$cnt]);             // Visszaadja az importált sorok számát JSON-ben  
    break;                                            // Kilép az import esetén  
  case 'listAll':                                     // Minden telefon lekérése  
    $res = $conn->query("SELECT * FROM phones");   // SQL lekérdezés az összes rekordra  
    if(!$res || $res->num_rows==0){                   // Ha nincs találat vagy hiba történt  
      http_response_code(404);                       // 404-es választ küld  
      echo json_encode(['error'=>'No phones found']); // Hibajelzés JSON-ben  
      break;                                         // Kilép a switchből  
    }
    $out = [];                                        // Kiírandó tömb inicializálása  
    while($r = $res->fetch_assoc()) $out[] = $r;      // Az összes sor beolvasása tömbbe  
    echo json_encode($out);                           // Tömb JSON formátumban  
    break;                                            // Kilép a switchből  
  case 'getById':                                     // Egy telefon lekérése ID alapján  
    $stmt = $conn->prepare("SELECT * FROM phones WHERE id=?"); // Előkészített lekérdezés  
    $stmt->bind_param('i',$id);                      // ID paraméter kötése  
    $stmt->execute();                                // Lekérdezés végrehajtása  
    $r = $stmt->get_result()->fetch_assoc();          // Eredmény egy sorban  
    if(!$r){                                         // Ha nincs találat  
      http_response_code(404);                       // 404-es választ küld  
      echo json_encode(['error'=>'Not found']);     // Hibajelzés JSON-ben  
    } else echo json_encode($r);                     // Ha van, visszaadja a rekordot JSON-ben  
    break;                                            // Kilép a switchből  
  case 'getByManufacturer':                          // Telefonok lekérése gyártó szerint  
    $stmt = $conn->prepare("SELECT * FROM phones WHERE manufacturer=?"); // Előkészített lekérdezés  
    $stmt->bind_param('s',$man);                    // Gyártó neve paraméterként  
    $stmt->execute();                                // Lekérdezés végrehajtása  
    $res = $stmt->get_result();                      // Eredmény beolvasása  
    if($res->num_rows==0){                           // Ha nincs találat  
      http_response_code(404);                       // 404-es választ küld  
      echo json_encode(['error'=>'None']);          // Hibajelzés JSON-ben  
    } else {                                         // Ha van találat  
      $out = [];                                     // Kiírandó tömb inicializálása  
      while($r = $res->fetch_assoc()) $out[] = $r;   // Az összes sor beolvasása tömbbe  
      echo json_encode($out);                        // Tömb JSON formátumban  
    }
    break;                                            // Kilép a switchből  
  default:                                           // Hibás action paraméter  
    http_response_code(400);                         // 400-as választ küld  
    echo json_encode(['error'=>'Invalid action']);  // Hibajelzés JSON-ben  
}
$conn->close();                                      // Adatbázis kapcsolat lezárása  
?>