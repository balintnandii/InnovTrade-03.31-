$(function(){                                  // DOM betöltődése után fut
    function show(data){                         // Eredmény megjelenítő függvény
      $('#output').empty();                     // Korábbi tartalom törlése
      $.each(data,function(i,g){                // Végigmegy az adatokon
        $('#output').append(                    // Dinamikus HTML beszúrása
          `<div><h3>${g.title}</h3><p>${g.genre} – ${g.developer}</p></div>`
        );
      });
    }
    $('#all').click(()=>                        // Összes játék gomb eseménye
      $.get('/api/games',show)                  // GET kérés az összes játékhoz
    );
    $('#id').click(()=>{                        // ID szerinti gomb eseménye
      let id=prompt('ID:');                     // ID bekérése prompttal
      $.get(`/api/games/${id}`, data=> show([data])) // GET kérés egy elemre
        .fail(()=>alert('Not found'));          // Hibakezelés 404 esetén
    });
    $('#genre').click(()=>{                     // Műfaj szerinti gomb eseménye
      let g=prompt('Műfaj:');                   // Műfaj bekérése
      $.get(`/api/games/genre/${g}`,show)       // GET kérés műfaj szerint
        .fail(()=>alert('None'));              // Hibakezelés
    });
  });