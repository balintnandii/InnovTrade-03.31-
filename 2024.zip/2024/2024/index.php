<?php
header('Content-Type: application/json');                                  // Beállítja, hogy a HTTP válasz JSON legyen  
$conn = new mysqli('localhost','root','','c64db');                       // Kapcsolat létrehozása MySQL-hez  
if($conn->connect_error){                                                  // Ha a kapcsolat nem jön létre  
  http_response_code(500);                                                  // Küldjön 500-as HTTP státuszkódot  
  echo json_encode(['error'=>'DB error']);                                 // JSON formátumú hibaüzenet  
  exit;                                                                     // Kilép a szkriptből  
}
$action = $_GET['action'] ?? 'listAll';                                     // Lekérdezés műveletének beolvasása, alapértelmezett: listAll  
$id = intval($_GET['id'] ?? 0);                                             // ID paraméter beolvasása és egész számmá konvertálása  
$genre = $_GET['genre'] ?? '';                                               // Műfaj paraméter beolvasása, ha nincs, üres string  
switch($action){                                                            // A művelet típusától függően választ  
  case 'import':                                                            // "import" akció: SQL fájl végrehajtása  
    $sql = file_get_contents(__DIR__.'/sql.txt');                          // Beolvassa az sql.txt tartalmát  
    $conn->multi_query($sql);                                              // Több SQL utasítás egyszerre futtatása  
    do{;} while($conn->more_results() && $conn->next_result());            // Minden eredmény átfutása  
    echo json_encode(['imported'=>true]);                                   // Visszajelzés, hogy import sikeres  
    break;                                                                  // Kilép a switch-ből  

  case 'listAll':                                                           // "listAll" akció: az összes játék lekérése  
    $res = $conn->query("SELECT * FROM games");                          // SQL lekérdezés az összes sorra  
    if(!$res || $res->num_rows==0){                                         // Ha nincs találat vagy hiba történt  
      http_response_code(404);                                              // 404-es státuszkódot küld  
      echo json_encode(['error'=>'None']);                                 // Hibaüzenet JSON-ben  
      break;                                                                // Kilép a switch-ből  
    }
    $out = [];                                                              // Eredmény tömb inicializálása  
    while($row = $res->fetch_assoc()) $out[] = $row;                        // Minden sor hozzáadása a tömbhöz  
    echo json_encode($out);                                                 // Tömb JSON formátumban visszaküldése  
    break;                                                                  // Kilép a switch-ből  

  case 'getById':                                                           // "getById" akció: egy játék lekérése ID alapján  
    $stmt = $conn->prepare("SELECT * FROM games WHERE id=?");            // Előkészített lekérdezés létrehozása  
    $stmt->bind_param('i',$id);                                             // ID paraméter kötése (integer)  
    $stmt->execute();                                                       // Lekérdezés végrehajtása  
    $row = $stmt->get_result()->fetch_assoc();                               // Eredmény beolvasása egy asszociatív tömbként  
    if(!$row){                                                              // Ha nincs találat  
      http_response_code(404);                                              // 404-es státuszkód  
      echo json_encode(['error'=>'Not found']);                            // Hibajelzés JSON-ben  
    } else {
      echo json_encode($row);                                               // Ha van találat, visszaadja a rekordot  
    }
    break;                                                                  // Kilép a switch-ből  

  case 'getByGenre':                                                        // "getByGenre" akció: játékok lekérése műfaj szerint  
    $stmt = $conn->prepare("SELECT * FROM games WHERE genre=?");          // Előkészített lekérdezés  
    $stmt->bind_param('s',$genre);                                          // Műfaj paraméter kötése (string)  
    $stmt->execute();                                                       // Lekérdezés futtatása  
    $res = $stmt->get_result();                                              // Eredmény beolvasása  
    if($res->num_rows==0){                                                   // Ha nincs találat  
      http_response_code(404);                                              // 404-es státuszkód  
      echo json_encode(['error'=>'None']);                                 // Hibajelzés  
    } else {
      $out = [];                                                            // Eredmény tömb inicializálása  
      while($r = $res->fetch_assoc()) $out[] = $r;                          // Soronként tömb feltöltése  
      echo json_encode($out);                                               // Tömb visszaadása JSON-ként  
    }
    break;                                                                  // Kilép a switch-ből  

  default:                                                                  // Alapértelmezett ág, ismeretlen akció esetén  
    http_response_code(400);                                                 // 400-as (Bad Request) státuszkód  
    echo json_encode(['error'=>'Invalid']);                                 // Hibajelzés  
}
$conn->close();                                                             // Adatbázis kapcsolat lezárása  
?>