<?php
header('Content-Type: application/json'); // JSON tartalomtípus beállítása

$host = 'localhost';        // Adatbázis hoszt
$user = 'root';             // Felhasználónév
$pass = '';                  // Jelszó
$db   = 'mydb';              // Adatbázis neve

$conn = new mysqli($host, $user, $pass, $db); // Kapcsolat létrehozása
if ($conn->connect_error) {  // Ha a kapcsolat sikertelen
    http_response_code(500); // 500-as HTTP hiba visszaküldése
    echo json_encode(['error' => 'DB connection failed']); // Hibaüzenet JSON formátumban
    exit;                   // Kilépés a szkriptből
}

$action = $_GET['action'] ?? 'list'; // Lekért művelet: list vagy get, alapértelmezett list
switch ($action) {
    case 'list': // Terméklista lekérése
        $res = $conn->query("SELECT * FROM products"); // SQL lekérdezés futtatása
        $products = []; // Eredmény tömb inicializálása
        while ($row = $res->fetch_assoc()) { // Soronként olvasás
            $products[] = $row; // Hozzáadás a tömbhöz
        }
        echo json_encode($products); // Tömb JSON formátumban
        break;

    case 'get': // Egy termék lekérése ID alapján
        $id = intval($_GET['id'] ?? 0); // ID egész számra konvertálása
        $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?"); // Előkészített lekérdezés
        $stmt->bind_param('i', $id); // Paraméter kötése (integer)
        $stmt->execute(); // Lekérdezés végrehajtása
        $res = $stmt->get_result(); // Eredmény lekérése
        echo json_encode($res->fetch_assoc()); // Első sor JSON formátumban
        break;

    default: // Hibás művelet
        http_response_code(400); // 400-as HTTP hiba
        echo json_encode(['error' => 'Invalid action']); // Hibaüzenet JSON-ben
}

$conn->close(); // Kapcsolat bezárása