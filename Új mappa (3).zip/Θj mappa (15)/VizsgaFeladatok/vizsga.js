async function fetchProducts() {                          // Aszinkron függvény a termékek lekéréséhez
    const res = await fetch('http://localhost/index.php?action=list'); // API hívás listára
    const products = await res.json();                      // JSON adat feldolgozása
    const container = document.querySelector('.product-list'); // DOM elem kiválasztása
    products.forEach(p => {                                  // Minden termékre
      const div = document.createElement('div');            // Új div létrehozása
      div.innerHTML = `<h2>${p.name}</h2><p>${p.price} Ft</p>`; // HTML tartalom
      container.appendChild(div);                           // Hozzáadás a DOM-hoz
    });
  }
  
  window.onload = fetchProducts;                            // Oldal betöltődése után futtatás