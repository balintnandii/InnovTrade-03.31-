$(function(){                                  // Oldal betöltődése után fut le  <!-- DOM ready -->
    function show(data){                       // Eredmény megjelenítő függvény -->
      $('#output').empty();                   // Korábbi tartalom törlése -->
      $.each(data,function(i,item){           // Minden elemen végigmegy -->
        $('#output').append(
          `<div><h3>${item.name}</h3><p>${item.manufacturer} – ${item.price}</p></div>`
        );                                      // Dinamikus HTML létrehozása -->
      });
    }
    $('#all').click(()=>                      // Összes gombra kattintás -->
      $.get('/api/tablets',show)              // GET kérés a /api/tablets végpontra -->
    );
    $('#id').click(()=>{                      // ID gombra kattintás -->
      let id=prompt('ID:');                   // ID bekérése prompttal -->
      $.get(`/api/tablets/${id}`,show)        // GET kérés ID alapján -->
        .fail(()=>alert('Nincs adat'));       // Hibakezelés 404 esetén -->
    });
    $('#manu').click(()=>{                    // Gyártó gombra kattintás -->
      let m=prompt('Gyártó:');                // Gyártó neve prompttal -->
      $.get(`/api/tablets/manufacturer/${m}`,show) // GET kérés gyártó szerint -->
        .fail(()=>alert('Nincs adat'));       // Hibakezelés -->
    });
  });