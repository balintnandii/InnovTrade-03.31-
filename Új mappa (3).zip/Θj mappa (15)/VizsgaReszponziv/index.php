<!DOCTYPE html>                        <!-- Dokumentum típus definiálása -->
<html lang="hu">                     <!-- Nyelvi beállítás magyar -->
<head>
  <meta charset="UTF-8">             <!-- Karakterkódolás UTF-8 -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Reszponzivitás beállítása -->
  <link rel="stylesheet" href="style.css"> <!-- Külső CSS fájl behívása -->
  <title>Tabletek</title>             <!-- Oldalcím -->
</head>
<body>
  <nav>                                <!-- Navigációs menü -->
    <ul>
      <li><a href="#products">Termékek</a></li>   <!-- Menüponthivatkozás -->
      <li><a href="#about">Rólunk</a></li>
      <li><a href="#contact">Elérhetőség</a></li>
    </ul>
  </nav>
  <section id="products">             <!-- Termékek szekció -->
    <h1>Tabletek</h1>                   <!-- Cím -->
    <div class="grid">                <!-- Rács elrendezés div -->
      <article>                        <!-- Egy termék kártya -->
        <img src="tablet1.jpg" alt="Tablet1">   <!-- Termékkép -->
        <h2>iPad</h2>                  <!-- Termék neve -->
        <p>Lorem ipsum…</p>            <!-- Leírás (lorem-ipsum.txt tartalma) -->
      </article>
      <!-- Ismételd meg még 6x a kártyát -->
    </div>
  </section>
  <section id="about">               <!-- Rólunk szekció -->
    <h1>Rólunk</h1>
    <p><!-- lorem-ipsum.txt itt olvasva -->Lorem ipsum…</p> <!-- Cég bemutatása -->
  </section>
  <section id="contact">             <!-- Elérhetőség szekció -->
    <h1>Kapcsolat</h1>
    <p>Email: info@tablet.hu</p>       <!-- Kapcsolati információ -->
  </section>
</body>
</html>