<?php
header('Content-Type: application/json');   // Beállítja a válasz típusát JSON-ra  <!-- JSON válasz formátum -->
$conn=new mysqli('localhost','root','','mydb'); // Kapcsolódás MySQL-hez a beállított adatokkal  <!-- DB kapcsolat -->
if($conn->connect_error){                   // Ha a kapcsolat nem jött létre  <!-- Hibaellenőrzés -->
  http_response_code(500);                 // 500-as hibakód visszaküldése  <!-- Szerverhiba -->
  echo json_encode(['error'=>'DB error']); // Hibát jelző JSON üzenet  <!-- Hibaüzenet -->
  exit;                                    // Kilép a szkriptből  <!-- Szkript leállítása -->
}
$action=$_GET['action']??'listAll';         // Lekérdezés típusának beolvasása vagy alapértelmezett  <!-- Művelet kiválasztása -->
$id=intval($_GET['id']??0);                // ID paraméter beolvasása egész számként  <!-- ID lekérdezéshez -->
$man=$_GET['manufacturer']??'';            // Gyártó paraméter beolvasása  <!-- Gyártó szerinti szűrés -->
switch($action){                           // Művelet szerinti elágazás  <!-- Action switch -->
  case 'import':                          // Import akció  <!-- adatfeltöltés -->
    $f=__DIR__.'/tabletek.txt';           // Fájl elérési útja  <!-- tabletek.txt beolvasása -->
    if(!file_exists($f)){                 // Ha nincs fájl  <!-- Fájl létezés ellenőrzése -->
      http_response_code(404);           // 404-es válasz  <!-- Nincs fájl -->
      echo json_encode(['error'=>'No file']); // Hibajelzés JSON-ben  <!-- Hibaüzenet -->
      exit;                              // Kilépés  <!-- Szkript befejezése -->
    }
    $lines=file($f,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES); // Sorok beolvasása tömbbe  <!-- Fájl olvasás -->
    $stmt=$conn->prepare("INSERT INTO tablets(name,manufacturer,price) VALUES(?,?,?)"); // Beszúró lekérdezés  <!-- Előkészített SQL -->
    $cnt=0;                               // Számláló inicializálása  <!-- importált sorok száma -->
    foreach($lines as $l){               // Minden beolvasott sorra  <!-- ciklus -->
      list($n,$m,$p)=explode(';',$l);     // Sor szétbontása pontoknál  <!-- adatok kinyerése -->
      $stmt->bind_param('ssd',$n,$m,$p);  // Paraméterek kötése  <!-- SQL paraméterezés -->
      $stmt->execute();                  // Lekérdezés végrehajtása  <!-- Beszúrás -->
      $cnt++;                            // Számláló növelése  <!-- importálások száma -->
    }
    echo json_encode(['imported'=>$cnt]); // Visszaadja az importált sorok számát  <!-- JSON válasz -->
    break;                                // Kilép a switchből  <!-- import vég -->
  case 'listAll':                        // Összes tablet lekérése  <!-- lista akció -->
    $res=$conn->query("SELECT * FROM tablets"); // SQL lekérdezés  <!-- összes adat -->
    if(!$res||$res->num_rows==0){         // Ha nincs eredmény  <!-- üres eredmény -->
      http_response_code(404);           // 404-es válasz  <!-- Nem található -->
      echo json_encode(['error'=>'None']); // Hibajelzés JSON-ben  <!-- üres lista -->
      break;
    }
    $out=[];                             // Eredmény tömb inicializálása  <!-- válasz tömb -->
    while($r=$res->fetch_assoc())$out[]=$r; // Soronként bejárás  <!-- adatok gyűjtése -->
    echo json_encode($out);             // JSON válasz  <!-- lista küldése -->
    break;
  case 'getById':                        // Egy adott ID lekérése  <!-- get akció -->
    $stmt=$conn->prepare("SELECT * FROM tablets WHERE id=?"); // Előkészített lekérdezés -->
    $stmt->bind_param('i',$id);         // ID paraméter kötése  <!-- ID meghatározása -->
    $stmt->execute();                   // Lekérdezés futtatása  <!-- SQL futtatás -->
    $r=$stmt->get_result()->fetch_assoc(); // Eredmény egy sorában  <!-- adat beolvasása -->
    if(!$r){                            // Ha nincs találat  <!-- üres eredmény -->
      http_response_code(404);         // 404-es válasz  <!-- Not found -->
      echo json_encode(['error'=>'Not found']); // Hibajelzés JSON-ben  <!-- üres adat -->
    } else echo json_encode($r);       // Egy sor JSON-ként  <!-- adat küldése -->
    break;
  case 'getByManufacturer':              // Gyártó szerinti lekérdezés  <!-- szűrés -->
    $stmt=$conn->prepare("SELECT * FROM tablets WHERE manufacturer=?"); // Előkészített lekérdezés -->
    $stmt->bind_param('s',$man);        // Gyártó paraméter kötése  <!-- paraméter -->
    $stmt->execute();                   // Lekérdezés futtatása  <!-- SQL futtatás -->
    $res=$stmt->get_result();           // Eredmény beolvasása  <!-- eredmény -->
    if($res->num_rows==0){              // Ha nincs találat  <!-- üres eredmény -->
      http_response_code(404);         // 404-es válasz  <!-- Not found -->
      echo json_encode(['error'=>'None']); // Hibajelzés JSON-ben  <!-- üres lista -->
    } else {                            // Ha van találat  <!-- lista -->
      $out=[]; while($r=$res->fetch_assoc())$out[]=$r; echo json_encode($out); // Adatok JSON-ben  <!-- lista küldése -->
    }
    break;
  default:                              // Hibás action paraméter  <!-- alapértelmezett -->
    http_response_code(400);           // 400-as válasz  <!-- Bad request -->
    echo json_encode(['error'=>'Invalid']); // Hibajelzés JSON-ben  <!-- érvénytelen -->
}
$conn->close();                        // Adatbázis kapcsolat lezárása  <!-- Cleanup -->
?>