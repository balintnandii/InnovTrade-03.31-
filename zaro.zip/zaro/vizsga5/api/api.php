<?php
header("Content-Type: application/json"); // Beállítjuk, hogy a válasz típusa JSON legyen

require_once("db.php"); // Betöltjük az adatbázis kapcsolatot tartalmazó külön fájlt

$uri = explode("/", $_SERVER['REQUEST_URI']); // Az URL-t darabokra bontjuk / mentén (pl.: /api/tabletek/2 -> ['', 'api', 'tabletek', '2'])

if (count($uri) < 3 || $uri[1] != 'api') { // Ha túl rövid az URL, vagy nem 'api'-val kezdődik
    http_response_code(404); // 404-es hibakód küldése
    echo json_encode(["error" => "Érvénytelen végpont."]); // Hibaüzenet JSON formátumban
    exit; // Kilépünk a programból
}

$conn = getConnection(); // Meghívjuk a db.php fájlban lévő függvényt, ami visszaad egy PDO adatbázis kapcsolatot

if ($uri[2] == "tabletek") { // Ha a 3. rész "tabletek" (tehát: /api/tabletek vagy /api/tabletek/ID)
    
    if (isset($uri[3])) { // Ha van 4. rész, tehát egy ID-t kaptunk (pl. /api/tabletek/2)
        $id = intval($uri[3]); // Átalakítjuk számra (int típusra)
        
        $stmt = $conn->prepare("SELECT * FROM tabletek WHERE id = ?"); // Előkészítjük az SQL lekérdezést az ID alapján
        $stmt->execute([$id]); // Lefuttatjuk a lekérdezést a megadott ID-vel
        $tablet = $stmt->fetch(PDO::FETCH_ASSOC); // Egyetlen sor eredményt kérünk asszociatív tömbként

        if ($tablet) { // Ha létezik ilyen tablet ID-vel
            echo json_encode($tablet); // Visszaküldjük JSON formátumban
        } else {
            http_response_code(404); // Ha nincs ilyen tablet, akkor 404 hiba
            echo json_encode(["error" => "Nem található ilyen tablet."]); // Hibaüzenet JSON-ben
        }

    } else {
        // Ha nincs ID, akkor az összes tabletet kérjük le
        $stmt = $conn->query("SELECT * FROM tabletek"); // Egyszerű lekérdezés az összes sorra
        $tabletek = $stmt->fetchAll(PDO::FETCH_ASSOC); // Az összes rekordot lekérjük tömbként
        echo json_encode($tabletek); // JSON tömbként visszaadjuk
    }

} elseif ($uri[2] == "gyarto" && isset($uri[3])) { // Ha az útvonal gyártó alapú (pl. /api/gyarto/Samsung)
    
    $gyarto = urldecode($uri[3]); // A gyártó nevet URL-dekódoljuk (pl. ha szóköz vagy speciális karakter van)
    
    $stmt = $conn->prepare("SELECT * FROM tabletek WHERE gyarto = ?"); // Előkészítjük az SQL lekérdezést gyártó alapján
    $stmt->execute([$gyarto]); // Lefuttatjuk a lekérdezést a megadott gyártónévvel
    $eredmeny = $stmt->fetchAll(PDO::FETCH_ASSOC); // Több rekordot kérünk le, mint tömb

    if ($eredmeny) { // Ha van eredmény
        echo json_encode($eredmeny); // Visszaadjuk JSON-ben
    } else {
        http_response_code(404); // Nincs ilyen gyártó
        echo json_encode(["error" => "Nincs ilyen gyártó."]); // Hibajelzés JSON-ben
    }

} else {
    http_response_code(404); // Ha sem "tabletek", sem "gyarto" nem volt az útvonalban
    echo json_encode(["error" => "Nem létező végpont."]); // Végpont nem ismeretes, hibaüzenet
}
