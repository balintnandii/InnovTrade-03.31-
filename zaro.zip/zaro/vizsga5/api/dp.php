<?php
function getConnection() { // Függvény, amely létrehoz egy adatbázis kapcsolatot

    $host = "localhost";         // A MySQL szerver címe (helyi gépen: localhost)
    $dbname = "tabletek_db";     // Az adatbázis neve (amit létrehoztál)
    $user = "root";              // Felhasználónév (XAMPP-ban ez általában 'root')
    $pass = "";                  // Jelszó (XAMPP esetén gyakran üres)

    return new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    // PDO objektum létrehozása, automatikusan beállított UTF-8 karakterkódolással
}
