// Összes tablet lekérése az API-ból
function osszesTablet() {
    // Lekéri az összes tabletet az API megfelelő végpontjáról
    fetch('/api/tabletek') // HTTP GET kérés a '/api/tabletek' címre
      .then(response => response.json()) // Válasz JSON-ná alakítása
      .then(data => megjelenitTableteket(data)); // A kapott adatot átadjuk a megjelenítő függvénynek
  }
  
  // Egyetlen tablet lekérése ID alapján
  function tabletID(id) {
    // Az adott azonosítójú tabletet kérjük le az API-ból
    fetch(`/api/tabletek/${id}`) // A végpont például: /api/tabletek/2
      .then(response => {
        // Ellenőrizzük, hogy 404-es hibát kaptunk-e
        if (response.status === 404) {
          alert("Nem található ilyen tablet!"); // Hibaüzenet a felhasználónak
          return null; // Megszakítjuk a feldolgozást
        }
        return response.json(); // Ha nem volt hiba, folytatjuk a JSON feldolgozással
      })
      .then(data => {
        // Csak akkor dolgozunk tovább, ha kaptunk adatot
        if (data) {
          megjelenitTableteket([data]); // A megjelenítő függvény tömböt vár, ezért csomagoljuk be []
        }
      });
  }
  
  // Tabletek lekérése gyártó alapján
  function gyartoSzerint(gyarto) {
    // A megadott gyártónév alapján kérjük le a tableteket
    fetch(`/api/gyarto/${gyarto}`) // Például: /api/gyarto/Samsung
      .then(response => response.json()) // JSON formátumú választ várunk
      .then(data => megjelenitTableteket(data)); // Átadjuk az adatokat a megjelenítőnek
  }
  
  // Megjeleníti a kapott tableteket a HTML oldalon
  function megjelenitTableteket(tabletek) {
    // Az 'api-eredmeny' ID-jű div-et választjuk ki, ez lesz a célterület
    const container = document.getElementById('api-eredmeny');
  
    container.innerHTML = ''; // Előző tartalom törlése, hogy friss adatok kerüljenek be
  
    // Végigmegyünk a kapott tabletek tömbön
    tabletek.forEach(tablet => {
      // Létrehozunk egy div-et a tablet számára
      const kartya = document.createElement('div');
      kartya.className = 'kartya'; // Hozzáadjuk a CSS osztályt
  
      // Létrehozzuk a képet
      const kep = document.createElement('img');
      kep.src = `tablet${tablet.id}.jpg`; // A kép fájlneve a tablet ID alapján (pl. tablet2.jpg)
      kep.alt = tablet.model; // Alternatív szöveg a képen, ha nem töltődne be
  
      // Leírás beállítása
      const leiras = document.createElement('p');
      leiras.textContent = `${tablet.gyarto} ${tablet.model} – ${tablet.ar} Ft`; // Gyártó + modell + ár
  
      // A kártya div-hez hozzáadjuk a képet és leírást
      kartya.appendChild(kep);
      kartya.appendChild(leiras);
  
      // A teljes kártyát hozzáadjuk a fő containerhez
      container.appendChild(kartya);
    });
  }
  