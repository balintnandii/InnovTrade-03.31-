﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1;

class Futok
{
    public string Nev { get; set; }

    public double Ido { get; set; }

    public int Pont { get; set; }

    public override string ToString()
    {
        return Nev + "    " + Ido;
    }
}

public partial class MainWindow : Window
{
    List<Futok> futok = new List<Futok>();
    public MainWindow()
    {
        InitializeComponent();

        string[] adatok = File.ReadAllLines("futok.txt");

        for (int i = 0; i < adatok.Length; i++)
        {
            string[] sor = adatok[i].Split(';');

            futok.Add(new Futok { 
                Nev = sor[0], Ido = double.Parse(sor[1]), Pont = int.Parse(sor[2])
            });
        }

        Lista.ItemsSource = futok;
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
        Neve.Content = "Idő:";
        Ido.Content = ((Futok)Lista.SelectedItem).Ido;
    }
}