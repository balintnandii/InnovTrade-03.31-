document.addEventListener("DOMContentLoaded", () => { 
  // Várja, hogy a teljes DOM betöltődjön, majd végrehajtja a callback függvényt

  const container = document.getElementById("container"); 
  // Lekéri a #container elemre mutató referencia, ide fogjuk beszúrni a dinamikus dobozokat

  fetch('adatok.php') 
  // HTTP kérést indít az adatok lekérésére a 'adatok.php' végpontról

    .then(response => { 
      // Első .then: megkapja a válasz (response) objektumot

      if (!response.ok) { 
        // Ellenőrzi, hogy a HTTP státusz 200–299 tartományban van-e
        throw new Error('Hálózati hiba: ' + response.status); 
        // Ha nem OK, hibát dob a státuszkód szövegével
      }

      return response.json(); 
      // A választ JSON-formátumba alakítja, és továbbadja a következő .then-nek
    })

    .then(data => { 
      // Második .then: megkapja a dekódolt JSON-adatokat tömb formájában

      console.log("Kapott adatok:", data); 
      // Kiírja a konzolra a kapott adatsorokat hibakeresés céljából

      data.forEach(tablet => { 
        // Végigiterál az egyes tabletek objektumain

        const div = document.createElement("div"); 
        // Létrehoz egy új <div> elemet minden tablethez

        div.classList.add("doboz1"); 
        // Hozzáadja a 'doboz1' CSS-osztályt az új <div>-hez

        div.innerHTML = `
          <img src="${tablet.kep}" >
          <div class="Leírás1">
            <h3>${tablet.gyarto}</h3>
            <div class="szoveg1">
              <p>OS: ${tablet.operacios_rendszer}</p>
              <p>Ár: ${tablet.ar} Ft</p>
            </div>
          </div>
        `; 
        // Kitölti az új <div> belső HTML-jét a tablet adataival:
        // — <img>: a kép URL-je
        // — gyártó, operációs rendszer és ár megjelenítése cím és bekezdések formájában

        container.appendChild(div); 
        // Beszúrja az elkészült dobozt a #container elem végére
      });
    })

    .catch(error => { 
      // Hibakezelő ág: lefut, ha a fetch vagy bármely előző .then hibát dob

      console.error('Hiba történt:', error); 
      // Hibát ír ki a konzolra a részletekkel
    });
});

// A maradék két lekérdezés ugyanúgy működhet, csak más PHP-végpontokat adsz meg fetch-ben: pl. fetch('elerhetoseg.php')

// Opció: jQuery-vel a navigáció animált elrejtéséhez/megjelenítéséhez

// $(document).ready(function () {
//     // Várja, hogy az egész oldal betöltődjön jQuery-vel

//     $(".elso").click(function (e) { 
//         // Ha az első menüpontot kattintják
//         $(".masodik").hide();   // Elrejti a második menüpont tartalmát
//         $(".harmadik").hide();  // Elrejti a harmadik menüpont tartalmát
//         $(".elso").show();      // Megjeleníti az első menüpont tartalmát
//     });

//     $(".masodik").click(function (e){ 
//         // Ha a második menüpontot kattintják
//         $(".elso").hide();
//         $(".harmadik").hide();
//         $(".masodik").show();
//     });

//     $(".harmadik").click(function (e) {
//         // Ha a harmadik menüpontot kattintják
//         $(".elso").hide();
//         $(".masodik").hide();
//         $(".harmadik").show();
//     });
// });
