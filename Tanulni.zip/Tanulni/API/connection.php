<?php
$servername = "localhost";      // A MySQL szerver hosztneve, itt helyben (`localhost`)
$username   = "root";           // Adatbázis-felhasználónév, alapértelmezett root
$password   = "";               // Adatbázis-jelszó, jelen esetben üres
$database   = "tablet";         // Csatlakozni kívánt adatbázis neve
$conn       = new mysqli(       // Új MySQLi kapcsolat létrehozása a következő paraméterekkel:
    $servername,                // — a szerver címe
    $username,                  // — a felhasználónév
    $password,                  // — a jelszó
    $database                   // — az adatbázis neve
);
