<?php
header("Content-type: application/json; charset=utf-8"); 
// Beállítja a válasz tartalomtípusát JSON-ra és karakterkódolását UTF-8-ra

require_once "connection.php"; 
// Betölti a korábban definiált adatbázis-kapcsolatot (connection.php fájl)

/* SQL-lekérdezés definiálása: az összes rekordot kérjük le a "tabletek" táblából */
$sql = "SELECT * FROM tabletek;"; 

/* A lekérdezés végrehajtása a mysqli_query függvénnyel */
$result = mysqli_query($conn, $sql); 

$data = []; 
// Üres tömb inicializálása, amibe a rekordokat fogjuk gyűjteni

/* Ha van eredmény és legalább egy sor található */
if ($result && mysqli_num_rows($result) > 0) {
    /* Soronként bejárjuk az eredményhalmazt */
    while ($row = mysqli_fetch_assoc($result)) {
        /* Minden rekord mezőit társítjuk egy asszociatív tömbhöz */
        $data[] = array(
            "kep"                  => $row['kep'],                  // Kép URL vagy útvonal
            "gyarto"               => $row['gyarto'],               // A gyártó neve
            "operacios_rendszer"   => $row['operacios_rendszer'],   // Operációs rendszer megnevezése
            "ar"                   => $row['ar'],                   // Ár érték
        );
    }
    http_response_code(200); 
    // Beállítja a HTTP státuszkódot 200-ra (OK)
    echo json_encode($data); 
    // A rekordokat JSON-formátumban visszaküldi a kliensnek
} else {
    http_response_code(404); 
    // Ha nincs találat, 404-es státuszkódot küld (Not Found)
    echo json_encode(["message" => "Nincsenek elérhető adatok."]); 
    // Hibaüzenetet JSON-ban küldi el
}
?>
